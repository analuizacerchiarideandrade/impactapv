package com.example.myapplication

import android.content.Context
import android.content.SharedPreferences

class SecurityPreferences(context: Context) {
    //criaca de um variavel chamada shared que pega as preferencias
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("Motivation", Context.MODE_PRIVATE)
    //funcao que guarda senha, chave: valor ambis string
    fun storeString(key: String, value: String) {
        //este compartojamento de senhas executa uma edicao podno chave e valor
        this.sharedPreferences.edit().putString(key, value).apply()
    }

    fun getStoredString(key: String): String {
        return this.sharedPreferences.getString(key, "") ?: ""
    }

}